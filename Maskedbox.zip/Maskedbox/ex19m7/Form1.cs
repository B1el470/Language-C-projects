namespace ex19m7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void evitar_repeti��o(string mascara, string tipo)
        {
            maskedTextBox1.Text = " ";
            maskedTextBox1.Mask = mascara;
            label1.Text = tipo;
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            maskedTextBox1.Height = 100;
            maskedTextBox1.Width = 450;
        }

        private void butthr_Click(object sender, EventArgs e)
        {
            evitar_repeti��o("00:00", "Hora");
        }

        private void buttcd_Click(object sender, EventArgs e)
        {
            evitar_repeti��o("0000-000", "C�digo Postal");
        }

        private void buttm_Click(object sender, EventArgs e)
        {
            evitar_repeti��o("000.000,00�", "Moeda");

        }

        private void buttdata_Click(object sender, EventArgs e)
        {
            evitar_repeti��o("00/00/0000", "Data");
        }

        private void buttpw_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Text = " ";
            maskedTextBox1.Mask = "AAAAAAAAAA";
            maskedTextBox1.PasswordChar = '*';
            label1.Text = "Password";

        }

        private void butttel_Click(object sender, EventArgs e)
        {
            maskedTextBox1.PasswordChar = '\0';
            evitar_repeti��o("000 000 000", "Telefone");
        }
    }
}
