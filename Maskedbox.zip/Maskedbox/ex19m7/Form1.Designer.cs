﻿namespace ex19m7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            maskedTextBox1 = new MaskedTextBox();
            butthr = new Button();
            buttm = new Button();
            butttel = new Button();
            buttpw = new Button();
            buttcd = new Button();
            buttdata = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(190, 107);
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(355, 23);
            maskedTextBox1.TabIndex = 0;
            maskedTextBox1.MaskInputRejected += maskedTextBox1_MaskInputRejected;
            // 
            // butthr
            // 
            butthr.Location = new Point(190, 158);
            butthr.Name = "butthr";
            butthr.Size = new Size(112, 33);
            butthr.TabIndex = 1;
            butthr.Text = "Hora";
            butthr.UseVisualStyleBackColor = true;
            butthr.Click += butthr_Click;
            // 
            // buttm
            // 
            buttm.Location = new Point(454, 158);
            buttm.Name = "buttm";
            buttm.Size = new Size(106, 33);
            buttm.TabIndex = 2;
            buttm.Text = "Moeda";
            buttm.UseVisualStyleBackColor = true;
            buttm.Click += buttm_Click;
            // 
            // butttel
            // 
            butttel.Location = new Point(454, 219);
            butttel.Name = "butttel";
            butttel.Size = new Size(106, 35);
            butttel.TabIndex = 3;
            butttel.Text = "Telefone";
            butttel.UseVisualStyleBackColor = true;
            butttel.Click += butttel_Click;
            // 
            // buttpw
            // 
            buttpw.Location = new Point(329, 219);
            buttpw.Name = "buttpw";
            buttpw.Size = new Size(115, 35);
            buttpw.TabIndex = 4;
            buttpw.Text = "Password";
            buttpw.UseVisualStyleBackColor = true;
            buttpw.Click += buttpw_Click;
            // 
            // buttcd
            // 
            buttcd.Location = new Point(329, 158);
            buttcd.Name = "buttcd";
            buttcd.Size = new Size(106, 33);
            buttcd.TabIndex = 5;
            buttcd.Text = "Código Postal";
            buttcd.UseVisualStyleBackColor = true;
            buttcd.Click += buttcd_Click;
            // 
            // buttdata
            // 
            buttdata.Location = new Point(190, 219);
            buttdata.Name = "buttdata";
            buttdata.Size = new Size(112, 35);
            buttdata.TabIndex = 6;
            buttdata.Text = "Data";
            buttdata.UseVisualStyleBackColor = true;
            buttdata.Click += buttdata_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(190, 67);
            label1.Name = "label1";
            label1.Size = new Size(33, 37);
            label1.TabIndex = 7;
            label1.Text = "0";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(buttdata);
            Controls.Add(buttcd);
            Controls.Add(buttpw);
            Controls.Add(butttel);
            Controls.Add(buttm);
            Controls.Add(butthr);
            Controls.Add(maskedTextBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox maskedTextBox1;
        private Button butthr;
        private Button buttm;
        private Button butttel;
        private Button buttpw;
        private Button buttcd;
        private Button buttdata;
        private Label label1;
    }
}
